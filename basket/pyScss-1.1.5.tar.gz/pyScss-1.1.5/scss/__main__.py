import tool

tool.main()
