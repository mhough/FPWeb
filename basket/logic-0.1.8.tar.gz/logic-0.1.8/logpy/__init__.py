"""
LogPy is a Python library for logic and relational programming.
"""

from core import run, eq, var, conde, membero
from goals import seteq
from facts import Relation, fact, facts

__version__ = '0.1.8'
