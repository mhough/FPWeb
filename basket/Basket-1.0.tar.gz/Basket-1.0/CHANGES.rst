List of releases of Basket
==========================

1.0 (2012-05-14)
----------------

- add support for Python 3;

- fix a bug in 'prune' command that could cause Basket to prune the
  wrong version(s).


0.9 (2012-04-16)
----------------

- handle tar-bzipped ('.tar.bz2') archives. Thanks to Nathan McBride
  who reported the bug (`#1 <https://github.com/dbaty/Basket/issues/1>`_).


0.8 (2012-02-15)
----------------

First public release.